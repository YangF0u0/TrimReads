#ifndef __findline__
#define __findline__
#include <stdio.h>
#include <stdlib.h>

int FindLine(char* filename,char* target,int i);

#endif
