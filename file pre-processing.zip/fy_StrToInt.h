#ifndef __StrToInt__
#define __StrToInt__
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int StrToInt(char* str);

#endif
