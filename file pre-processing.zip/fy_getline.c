#include <stdio.h>
#include <stdlib.h>
#include "fy_getline.h"

void GetLine(char* filename,int i,char* line)
{
  FILE *pFile;
  int currentline=0;
  int IfClosed=0;

  pFile=fopen(filename,"r");

  while(fgets(line,1000,pFile)!=NULL)
  {
    if(currentline==i)  break;
    else  currentline++;
  }
  
  return;
}

