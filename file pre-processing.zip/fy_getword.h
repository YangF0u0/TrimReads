#ifndef __getword__
#define __getword__
#include <stdio.h>
#include <stdlib.h>

void DeleteBlanks(char* str);
void DeleteWord(char* str);
void GetWord(char* str,char* dest);

#endif
