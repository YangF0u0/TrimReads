#ifndef __getline__
#define __getline__
#include <stdio.h>
#include <stdlib.h>

void GetLine(char* filename,int i,char* str);

#endif

